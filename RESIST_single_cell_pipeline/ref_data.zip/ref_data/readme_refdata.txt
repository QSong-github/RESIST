Ref data files that need to download separately due to large size:
==========

The three input files below are not tracked in this repository. Download them into the data directory before running.

1. GSE70138_Broad_LINCS_Level4_ZSPCINF_mlr12k_n78980x22268_2015-06-30.gct
   LINCS L1000 Phase II Level 4 (z-scored, plate-control) signatures,
   78,980 profiles x 22,268 genes. GEO series GSE70138.
   Served gzipped, ~4.5 GB (4,838,794,601 bytes); ~14 GB uncompressed.
   https://ftp.ncbi.nlm.nih.gov/geo/series/GSE70nnn/GSE70138/suppl/GSE70138_Broad_LINCS_Level4_ZSPCINF_mlr12k_n78980x22268_2015-06-30.gct.gz

     curl -O https://ftp.ncbi.nlm.nih.gov/geo/series/GSE70nnn/GSE70138/suppl/GSE70138_Broad_LINCS_Level4_ZSPCINF_mlr12k_n78980x22268_2015-06-30.gct.gz
     gunzip GSE70138_Broad_LINCS_Level4_ZSPCINF_mlr12k_n78980x22268_2015-06-30.gct.gz

2. GSE70138_LINCS_Level4.rds
   Derived file - not distributed anywhere. It is an R serialization of
   file 1 and must be generated locally:

     # BiocManager::install("cmapR")
     library(cmapR)
     ds <- parse_gctx("GSE70138_Broad_LINCS_Level4_ZSPCINF_mlr12k_n78980x22268_2015-06-30.gct")
     saveRDS(ds, "GSE70138_LINCS_Level4.rds")

3. miRDB_v6.0_prediction_result.txt
   miRDB v6.0 MirTarget predicted miRNA-target interactions.
   Served gzipped, ~57 MB (59,483,982 bytes).
   https://mirdb.org/download/miRDB_v6.0_prediction_result.txt.gz
   (download page: https://mirdb.org/download.html)

     curl -O https://mirdb.org/download/miRDB_v6.0_prediction_result.txt.gz
     gunzip miRDB_v6.0_prediction_result.txt.gz

